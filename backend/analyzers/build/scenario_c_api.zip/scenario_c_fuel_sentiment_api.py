# Team: 68 | Name: Yunxiao Gao | Student ID: 1718413
from flask import request
from elasticsearch import Elasticsearch
import urllib3
import os

urllib3.disable_warnings(
    urllib3.exceptions.InsecureRequestWarning
)

# =========================
# Elasticsearch Connection
# =========================

ELASTIC_URL = os.environ.get(
    "ES_HOST",
    "https://elasticsearch-es-http.elastic.svc.cluster.local:9200"
)

ELASTIC_USER = os.environ.get("ES_USER", "elastic")
ELASTIC_PASSWORD = os.environ.get("ES_PASS", "elastic")

INDEX_NAME = "scenario_c_daily"

es = Elasticsearch(
    ELASTIC_URL,
    basic_auth=(ELASTIC_USER, ELASTIC_PASSWORD),
    verify_certs=False,
    request_timeout=60,
)

# =========================
# REST API
# =========================

def main():

    try:

        fuel_type = request.args.get("fuel_type")
        location = request.args.get("location")

        filters = []

        # Optional fuel_type filter
        if fuel_type:
            filters.append({
                "term": {
                    "fuel_type": fuel_type
                }
            })

        # Optional location filter
        if location:
            filters.append({
                "term": {
                    "location": location
                }
            })

        query = {
            "size": 1000,
            "sort": [
                {
                    "date": {
                        "order": "asc"
                    }
                }
            ],
            "query": {
                "bool": {
                    "filter": filters
                }
            }
        }

        response = es.search(
            index=INDEX_NAME,
            body=query
        )

        hits = response["hits"]["hits"]

        results = []

        for hit in hits:

            source = hit["_source"]

            results.append({
                "date": source.get("date"),
                "location": source.get("location"),
                "fuel_type": source.get("fuel_type"),

                "avg_fuel_price": source.get("avg_fuel_price"),

                "avg_sentiment_score": source.get(
                    "avg_sentiment_score"
                ),

                "negative_ratio": source.get(
                    "negative_ratio"
                ),

                "oil_post_count": source.get(
                    "oil_post_count"
                ),

                "negative_post_count": source.get(
                    "negative_post_count"
                )
            })

        return {
            "status": "success",
            "scenario": "scenario_c",
            "count": len(results),
            "filters": {
                "fuel_type": fuel_type,
                "location": location
            },
            "data": results
        }

    except Exception as e:

        return {
            "status": "error",
            "message": str(e)
        }


# =========================
# Local Test
# =========================

if __name__ == "__main__":

    print(main())